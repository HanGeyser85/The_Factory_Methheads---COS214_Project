#ifndef DRAGONCONSTRUCTION_H
#define DRAGONCONSTRUCTION_H

#include "DragonCraft.h"

using namespace std;

class DragonConsturction
{
	private: 
		DragonCraft* dC;

	protected: 
		virtual DragonCraft* factoryMethod() = 0;

	public: 
		DragonConsturction();
		void createDragonCraft();
		void setDC(DragonCraft* DC);
		DragonCraft* getDC();
};

#endif
