#ifndef DOOR_H
#define DOOR_H

#include "Decorator.h"

using namespace std;

class Door: public Decorator
{
	public: 
		Door();
		~Door(){}
};

#endif
