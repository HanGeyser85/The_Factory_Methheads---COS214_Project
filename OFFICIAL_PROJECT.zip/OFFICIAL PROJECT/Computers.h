#ifndef COMPUTERS_H
#define COMPUTERS_H

#include "Decorator.h"

using namespace std;

class Computers: public Decorator
{
	public:
		Computers();
		~Computers(){};
};

#endif
