#include <string>
#include "LaunchState.h"
#include "SystemsState.h"
#include "DragonCraft.h"
#include "State.h"

using namespace std;

SystemsState::SystemsState() : State("System State") {
}

void SystemsState::changeState(DragonCraft* Context) {
	Context->setState(new LaunchState());
}

