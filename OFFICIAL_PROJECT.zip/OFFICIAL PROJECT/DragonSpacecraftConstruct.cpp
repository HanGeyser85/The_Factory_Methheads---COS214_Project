#include "DragonSpacecraftConstruct.h"
#include "DragonCraft.h"
#include "DragonConsturction.h"

using namespace std;

DragonCraft* DragonSpacecraftConstruct::factoryMethod() {
	return new DragonSpacecraft();
}

