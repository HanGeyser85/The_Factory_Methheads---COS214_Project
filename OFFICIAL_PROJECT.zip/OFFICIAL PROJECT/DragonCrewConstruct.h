#ifndef DRAGONCREWCONSTRUCT_H
#define DRAGONCREWCONSTRUCT_H

#include "DragonCraft.h"
#include "DragonConsturction.h"
#include "DragonCrew.h"

using namespace std;

class DragonCrewConstruct: public DragonConsturction
{
	protected:
		virtual DragonCraft* factoryMethod();
};

#endif
