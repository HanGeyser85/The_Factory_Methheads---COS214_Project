#include <string>
#include <vector>
#include "DragonCraft.h"
#include "Decorator.h"
#include "Observer.h"
#include "State.h"

using namespace std;

DragonCraft::DragonCraft() {
}

string DragonCraft::getStateType() {
	return craftState->getStateType();
}

State* DragonCraft::getState() {
	return craftState;
}

void DragonCraft::setState(State* S) {
	craftState = S;
}

void DragonCraft::changeState() {
	craftState->changeState(this);
}
