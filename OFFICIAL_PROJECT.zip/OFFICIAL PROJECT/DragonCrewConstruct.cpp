#include "DragonCrewConstruct.h"
#include "DragonCraft.h"
#include "DragonConsturction.h"

using namespace std;

DragonCraft* DragonCrewConstruct::factoryMethod() {
	return new DragonCrew();
}

