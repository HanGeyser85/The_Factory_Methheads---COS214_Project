#ifndef WASTEDISPOSAL_H
#define WASTEDISPOSAL_H

#include "Decorator.h"

using namespace std;

class WasteDisposal: public Decorator
{
	public: 
		WasteDisposal();
		~WasteDisposal(){}
};

#endif
