#include <string>
#include "SystemsState.h"
#include "TransportState.h"
#include "DragonCraft.h"
#include "State.h"

using namespace std;

TransportState::TransportState() : State("Transport State") {
}

void TransportState::changeState(DragonCraft* Context) {
	Context->setState(new SystemsState());
}

