#ifndef LAUNCHSTATE_H
#define LAUNCHSTATE_H

#include <string>
#include "DragonCraft.h"
#include "State.h"

using namespace std;

class LaunchState: public State
{
	public: 
		LaunchState();
		virtual void changeState(DragonCraft* Context);
};

#endif
