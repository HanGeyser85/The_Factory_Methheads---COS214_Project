#ifndef SYSTEMSTATE_H
#define SYSTEMSTATE_H

#include <string>
#include "DragonCraft.h"
#include "State.h"

using namespace std;

class SystemsState: public State
{
	public: 
		SystemsState();
		virtual void changeState(DragonCraft* Context);
};

#endif
