#ifndef DRAGONSPACECRAFTCONSTRUCT_H
#define DRAGONSPACECRAFTCONSTRUCT_H

#include "DragonCraft.h"
#include "DragonConsturction.h"
#include "DragonSpacecraft.h"

using namespace std;

class DragonSpacecraftConstruct: public DragonConsturction
{
	protected: 
		virtual DragonCraft* factoryMethod();
};

#endif
