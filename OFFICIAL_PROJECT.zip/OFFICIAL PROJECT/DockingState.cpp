#include <string>
#include "DeployState.h"
#include "DockingState.h"
#include "DragonCraft.h"
#include "State.h"

using namespace std;

DockingState::DockingState() : State("Docking State") {
}

void DockingState::changeState(DragonCraft* Context) {
	Context->setState(new DeployState());
}

